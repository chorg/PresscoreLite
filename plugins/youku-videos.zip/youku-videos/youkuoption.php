<div class="wrap">
	<h2 class="nav-tab-wrapper">
    	<a href="<?php echo $this->get_menupage_url("youku-videos");?>" class="nav-tab">视频管理</a>
		<a href="<?php echo $this->get_menupage_url("youku-newvideo");?>" class="nav-tab">添加视频</a>
        <a href="<?php echo $this->get_menupage_url("youku-option");?>" class="nav-tab nav-tab-active">插件设置</a>
    </h2>
	<p></p>
	<?php $config = $this->config; $this->message();?>
	<form method="post" action="" >
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row"><label for="url">1. 视频页面地址</label></th>
					<td>
						<input id="url" type="text" class="regular-text code" name="url" value="<?=$config["url"];?>" />
						<strong> （分页需要，必须填写！）</strong>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="number">2. 页面视频数量</label></th>
					<td>
						<p><input name="number" type="number" step="1" min="1" id="number" value="<?php echo $config["number"];?>" class="small-text"><span>  默认每行4个视频，数量最好设置为4的倍数。</span></p>
					</td>					
				</tr>
				<tr valign="top">
					<th scope="row"><label for="time">3. 是否显示时长</label></th>
					<td>
						<p><input name="time" type="checkbox" id="time" value="1" <?php if($config["time"]) echo 'checked="checked"';?>><label for="time"> 显示视频时长</label><span>  （此选项默认开启）</span></p>
					</td>					
				</tr>			
				<tr valign="top">
					<th scope="row"><input type="submit" class="button-primary" value="保存设置"></th>				
				</tr>				
			</tbody>
		</table>
		<input type="hidden" name="ykvnonce" value="<?php echo wp_create_nonce( "ykv-updateconfig" ); ?>"/>
		<input type="hidden" name="action" value="ykv-update-config"/>
	</form>
</div>