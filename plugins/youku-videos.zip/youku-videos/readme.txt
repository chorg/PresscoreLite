=== Youku Videos ===
Contributors: Mufeng
Donate link: http://mufeng.me
Tags: video, youku, page
Tested up to: 3.7.1
Stable Tag: 1.0.0

优酷视频收藏功能。

== Description ==

<p>优酷视频收藏功能。</p>
<p>效果预览：<a href="http://mufeng.me">http://mufeng.me</a></p>

== Installation ==

1. Download the plugin archive and expand it.
2. Put the 'wp-youku' directory into your wp-content/plugins/ directory.
3. Activate WP-Youku Plugin.
4. Go to WP-Admin -> Settings -> WP-Youku to configure the plugin..
5. Go to widgets page to add the widget to your sidebar.

下载插件，上传到插件目录，在后台管理中激活插件，到设置页面进行简单设置即可。<br>

== Frequently Asked Questions ==

= To Display All The Videos =
* Create a new page template;
* Use:
<code>
<?php if (function_exists('the_youku')): ?>
	<?php the_youku(); ?>
<?php endif; ?>
</code>

== Screenshots ==

== Changelog ==

= 1.0.0 =
* Initial Release

== Upgrade Notice ==

None