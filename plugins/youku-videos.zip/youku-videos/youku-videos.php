<?php
/*
Plugin Name: Youku Videos
Plugin URI: http://mufeng.me/youku-videos.html
Description: 优酷视频收藏功能。
Version: 1.0.0
Author: Mufeng
Author URI: http://mufeng.me
*/

require_once(dirname(__FILE__).'/function.php');

?>