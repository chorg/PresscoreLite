<div class="wrap">
	<h2 class="nav-tab-wrapper">
    	<a href="<?php echo $this->get_menupage_url("youku-videos");?>" class="nav-tab nav-tab-active">视频管理</a>
		<a href="<?php echo $this->get_menupage_url("youku-newvideo");?>" class="nav-tab">添加视频</a>
        <a href="<?php echo $this->get_menupage_url("youku-option");?>" class="nav-tab">插件设置</a>
    </h2>
	<p></p>
	<?php $this->message();?>
	<form method="post" action="" >
		<?php
			$myListTable = new YKV_List_Table();
			$myListTable->prepare_items();
			$myListTable->display(); 
		?>
		<input type="hidden" name="ykvnonce" value="<?php echo wp_create_nonce( "ykv-manage" ); ?>"/>
	</form>
</div>
<style type="text/css">
.wp-list-table .column-id { width: 5%; }.wp-list-table .column-title { width: 55%; }.wp-list-table .column-created { width: 20%; }.wp-list-table .column-strtime { width: 20%;}</style>