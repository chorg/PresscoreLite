<div class="wrap">
	<h2 class="nav-tab-wrapper">
    	<a href="<?php echo $this->get_menupage_url("youku-videos");?>" class="nav-tab">视频管理</a>
		<a href="<?php echo $this->get_menupage_url("youku-newvideo");?>" class="nav-tab nav-tab-active">添加视频</a>
        <a href="<?php echo $this->get_menupage_url("youku-option");?>" class="nav-tab">插件设置</a>
    </h2>
	<p></p>
	<?php $this->message();?>
	<form method="post" action="" >
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row"><label for="new-url">1. Youku 视频地址</label></th>
					<td>
						<input id="new-url" type="text" class="regular-text code" name="new-url" />
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="new-title">2. Youku 视频标题</label></th>
					<td>
						<input id="new-title" type="text" class="regular-text code" name="new-title" />
						<p class="description">标题为非必需的，会自动从优酷读取标题。</p>
					</td>					
				</tr>
				<tr valign="top">
					<th scope="row"><input type="submit" class="button-primary" value="添加新视频"></th>				
				</tr>				
			</tbody>
		</table>
		<input type="hidden" name="ykvnonce" value="<?php echo wp_create_nonce( "ykv-newvideo" ); ?>"/>
		<input type="hidden" name="action" value="ykv-new-video"/>
	</form>	
</div>