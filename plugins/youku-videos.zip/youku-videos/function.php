<?php
global $YKV;
require dirname(__FILE__).'/class.youku.php';
if(!isset($YKV)){
	$YKV = new youku();
}

function the_youku(){
	global $YKV;
	$YKV->display();
}